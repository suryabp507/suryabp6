export class Admin {
    private id:any
    name:any
    password: any
}
