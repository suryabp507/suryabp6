import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcomeadmin',
  templateUrl: './welcomeadmin.component.html',
  styleUrls: ['./welcomeadmin.component.css']
})
export class WelcomeadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
